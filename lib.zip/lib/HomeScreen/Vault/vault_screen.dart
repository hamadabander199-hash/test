import 'package:flutter/material.dart';
import '../../../theme/app_theme.dart';

/// شاشة "الخزنة" — معرض الصور والفيديوهات المشفرة.
///
/// ⚠️ ده مجرد Placeholder دلوقتي عشان يظهر التاب في الـ Navigation.
/// التنفيذ الكامل (SQLCipher database، thumbnails، streaming decryption،
/// biometric auth، زرار الـ + لاستيراد ملفات enc... إلخ) هيتضاف في خطوة
/// لاحقة حسب المواصفات.
class VaultScreen extends StatelessWidget {
  const VaultScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        backgroundColor: AppColors.surface,
        title: const Text(
          "الخزنة",
          style: TextStyle(
            color: AppColors.textPrimary,
            fontWeight: FontWeight.w700,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_rounded, color: AppColors.primary),
            onPressed: () {
              // TODO: استيراد ملفات .enc فقط من التخزين.
            },
          ),
        ],
      ),
      body: const Center(
        child: Text(
          "لا يوجد محتوى بعد",
          style: TextStyle(
            color: AppColors.textMuted,
            fontSize: 14,
          ),
        ),
      ),
    );
  }
}
